public interface Arisque {
    final int prime=200 ;
}
